module com.semesterproject.mavenproject3 {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.semesterproject.mavenproject3 to javafx.fxml;
    exports com.semesterproject.mavenproject3;
}