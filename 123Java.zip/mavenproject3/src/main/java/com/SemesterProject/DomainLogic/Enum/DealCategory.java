package com.SemesterProject.DomainLogic.Enum;

public enum DealCategory
{
    Food,
    Energy,
    Knowledge
}
